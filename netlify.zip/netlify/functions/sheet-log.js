/**
 * 구글 시트 연동 프록시 (CORS 회피)
 * POST body: { webhook: "https://script.google.com/...", data: {...} }
 */
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: '' };
  }
  try {
    const { webhook, data } = JSON.parse(event.body || '{}');
    if (!webhook || !data) {
      return { statusCode: 400, body: JSON.stringify({ error: 'webhook, data required' }) };
    }
    const res = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const text = await res.text();
    return {
      statusCode: res.status,
      headers: { 'Content-Type': 'application/json' },
      body: text || JSON.stringify({ ok: res.ok })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message })
    };
  }
};
